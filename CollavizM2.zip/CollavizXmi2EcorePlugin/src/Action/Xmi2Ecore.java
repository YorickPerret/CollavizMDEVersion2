package Action;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.HashMap;
import java.util.Map;

import org.eclipse.core.resources.IFile;

public class Xmi2Ecore {
	protected Map<String, String> map ;
	
	public Xmi2Ecore(){
		this.map = new HashMap<String, String>();
	}
	
	public void generateXmi2Ecore(IFile modelFile, boolean needRootClass) {
		
		System.out.println(modelFile.getLocation());
		String[] tmp = modelFile.getLocation().toString().split("/");
		String dir = "";
		for(int i = 0;i<tmp.length-1;i++){
			dir += tmp[i]+"/";
		}
		
		try {
			//file
			BufferedReader buffer = new BufferedReader(new FileReader(modelFile.getLocation().toFile()));
			String texte = "";
			while(buffer.ready()){
				String readLine = buffer.readLine()+"\n";
				if(!buffer.ready() && needRootClass){
					//add root class before close file
					String rootClass = "	<eClassifiers xsi:type=\"ecore:EClass\" name=\"RootClass\">\n" +
							"		<eStructuralFeatures xsi:type=\"ecore:EReference\" name=\"objects\" upperBound=\"-1\" eType=\"#//WorldObject\"/>\n" +
							"	</eClassifiers>\n";
					texte+=rootClass;
				}
				texte+=readLine;
			}
			System.out.println("origine : \n\n"+texte);
			Action.Xmi2Ecore xmi2ecore = new Action.Xmi2Ecore();
			xmi2ecore.addCritere("CollavizPackage:Collaviz", "ecore:EPackage");
			xmi2ecore.addCritere("xmlns:CollavizPackage=\"platform:/resource/CollavizM2/model/M2Model/CollavizM2.ecore\"", "");
			xmi2ecore.addCritere("CollavizPackage:CollavizObject", "ecore:EClass");
			
			String convertir = "";
			convertir = xmi2ecore.convert(texte);
			
			System.out.println("convertir : \n\n"+convertir);
			
			//file save
			BufferedWriter writer = new BufferedWriter(new FileWriter(dir+"/"+modelFile.getName()+".ecore"));
			writer.write(convertir);
			writer.close();
			
			buffer.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void addCritere(String key, String value){
		map.put(key, value);
	}
	
	private String convert(String texte){
		String origine = texte;
		if(origine == null){
			origine = "";
		}
		for (Map.Entry<String, String> entry : map.entrySet())
		{
		    origine = origine.replaceAll(entry.getKey(), entry.getValue());
		}
		return origine;



	}
}

/**
 */
package CollavizPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Collaviz Object</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see CollavizPackage.CollavizPackagePackage#getCollavizObject()
 * @model
 * @generated
 */
public interface CollavizObject extends EClass {
} // CollavizObject

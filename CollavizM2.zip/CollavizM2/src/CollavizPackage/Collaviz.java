/**
 */
package CollavizPackage;

import org.eclipse.emf.ecore.EPackage;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Collaviz</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see CollavizPackage.CollavizPackagePackage#getCollaviz()
 * @model
 * @generated
 */
public interface Collaviz extends EPackage {
} // Collaviz

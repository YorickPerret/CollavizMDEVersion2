/**
 */
package CollavizPackage.impl;

import CollavizPackage.Collaviz;
import CollavizPackage.CollavizPackagePackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EPackageImpl;





/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Collaviz</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class CollavizImpl extends EPackageImpl implements Collaviz {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CollavizImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CollavizPackagePackage.Literals.COLLAVIZ;
	}

} //CollavizImpl

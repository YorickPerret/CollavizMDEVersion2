/**
 */
package CollavizPackage.impl;

import CollavizPackage.CollavizObject;
import CollavizPackage.CollavizPackagePackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EClassImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Collaviz Object</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class CollavizObjectImpl extends EClassImpl implements CollavizObject {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CollavizObjectImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CollavizPackagePackage.Literals.COLLAVIZ_OBJECT;
	}

} //CollavizObjectImpl

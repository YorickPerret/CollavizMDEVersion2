/**
 */
package CollavizPackage.impl;

import CollavizPackage.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class CollavizPackageFactoryImpl extends EFactoryImpl implements CollavizPackageFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static CollavizPackageFactory init() {
		try {
			CollavizPackageFactory theCollavizPackageFactory = (CollavizPackageFactory)EPackage.Registry.INSTANCE.getEFactory("platform:/resource/CollavizM2/model/M2Model/CollavizM2.ecore"); 
			if (theCollavizPackageFactory != null) {
				return theCollavizPackageFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new CollavizPackageFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CollavizPackageFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case CollavizPackagePackage.COLLAVIZ: return createCollaviz();
			case CollavizPackagePackage.COLLAVIZ_OBJECT: return createCollavizObject();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Collaviz createCollaviz() {
		CollavizImpl collaviz = new CollavizImpl();
		return collaviz;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CollavizObject createCollavizObject() {
		CollavizObjectImpl collavizObject = new CollavizObjectImpl();
		return collavizObject;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CollavizPackagePackage getCollavizPackagePackage() {
		return (CollavizPackagePackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static CollavizPackagePackage getPackage() {
		return CollavizPackagePackage.eINSTANCE;
	}

} //CollavizPackageFactoryImpl

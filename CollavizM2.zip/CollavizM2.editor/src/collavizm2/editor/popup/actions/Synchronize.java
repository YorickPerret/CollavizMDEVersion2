package collavizm2.editor.popup.actions;

import org.eclipse.core.resources.IFile;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IActionDelegate;
import org.eclipse.ui.IObjectActionDelegate;
import org.eclipse.ui.IWorkbenchPart;

import Action.Xmi2Ecore;

public class Synchronize implements IObjectActionDelegate {

	private Shell shell;
	private IFile file;
	
	/**
	 * Constructor for Action1.
	 */
	public Synchronize() {
		super();
	}

	/**
	 * @see IObjectActionDelegate#setActivePart(IAction, IWorkbenchPart)
	 */
	public void setActivePart(IAction action, IWorkbenchPart targetPart) {
		shell = targetPart.getSite().getShell();
	}

	/**
	 * @see IActionDelegate#run(IAction)
	 */
	public void run(IAction action) {
		try{
			Xmi2Ecore convert = new Xmi2Ecore();
			convert.generateXmi2Ecore(file, true);
			MessageDialog.openInformation(
					shell,
					"CollavizM2 Editor",
					"Synchronization success.");
		}catch(Exception e){
			e.printStackTrace();
			MessageDialog.openInformation(
					shell,
					"CollavizM2 Editor",
					"Errors are encountered during synchronization.");
		}
	}

	/**
	 * @see IActionDelegate#selectionChanged(IAction, ISelection)
	 */
	public void selectionChanged(IAction action, ISelection selection) {
		try{
			StructuredSelection select = (StructuredSelection) selection;
			Object first = select.getFirstElement();
			if(first != null){
				IFile file = (IFile) first;
				System.out.println(file.getLocation());
				this.file = file;
			}
			else{
				System.out.println("object null");
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}

}
